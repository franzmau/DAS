<!DOCTYPE html>
<html>
<body>

<form action="broker.php" method = "post">
  First name:<br>
  <input type="text" name="n" value="">
  <br>
  Last name:<br>
  <input type="text" name="l" value="">
  <br><br>
  <input type="submit" value="Submit">
</form>

<p>If you click the "Submit" button, the form-data will be sent to a broker then the broker will decided what to do with that information.</p>

</body>
</html>

